const SLIDER = true;
{
	let slide = false;
	console.log(slide);
}
console.log(SLIDER);