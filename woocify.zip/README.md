# woocify
Wordpress Starter Theme with Automated Tasks for Styles and Scripts (WP with Gulp.js)
